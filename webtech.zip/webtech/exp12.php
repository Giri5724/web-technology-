<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Factorial Calculator</title>
</head>
<body>

<h2>Factorial Calculator</h2>

<form method="post" action="">
    <label>Enter a number: </label>
    <input type="number" name="number" required>
    <input type="submit" value="Calculate">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $number = $_POST['number'];

    if (is_numeric($number) && $number >= 0) {

        // Function to calculate factorial
        function factorial($n) {
            $fact = 1;
            for ($i = 1; $i <= $n; $i++) {
                $fact *= $i;
            }
            return $fact;
        }

        $result = factorial($number);
        echo "<h3>Factorial of $number is: $result</h3>";

    } else {
        echo "<h3>Please enter a valid non-negative number.</h3>";
    }
}
?>

</body>
</html>
