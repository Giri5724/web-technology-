<!DOCTYPE html>
<html>
<head>
    <title>Arithmetic Operations</title>
</head>
<body>

<h2>Arithmetic Operation Calculator</h2>

<form method="post">
    Enter First Number: <input type="text" name="num1" required><br><br>
    Enter Second Number: <input type="text" name="num2" required><br><br>

    Select Operation:
    <select name="operation">
        <option value="add">Addition</option>
        <option value="subtract">Subtraction</option>
        <option value="multiply">Multiplication</option>
        <option value="divide">Division</option>
    </select><br><br>

    <input type="submit" name="submit" value="Calculate">
</form>
<?php
if(isset($_POST['submit'])){
    $num1 = $_POST['num1'];
    $num2 = $_POST['num2'];
    $operation = $_POST['operation'];

    if($operation == "add"){
        $result = $num1 + $num2;
        echo "<h3>Result of Addition: $result</h3>";
    }
    elseif($operation == "subtract"){
        $result = $num1 - $num2;
        echo "<h3>Result of Subtraction: $result</h3>";
    }
    elseif($operation == "multiply"){
        $result = $num1 * $num2;
        echo "<h3>Result of Multiplication: $result</h3>";
    }
    elseif($operation == "divide"){
        if($num2 != 0){
            $result = $num1 / $num2;
            echo "<h3>Result of Division: $result</h3>";
        } else {
            echo "<h3>Cannot divide by zero!</h3>";
        }
    } else {
        echo "<h3>Invalid Operation Selected</h3>";
    }
}
?>
</body>
</html>
