<?php
// Step 2: Define sample input strings
$email = "example@gmail.com";
$phone = "9876543210";

// Step 3: Create a regular expression pattern for email
$emailPattern = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/";

// Step 4: Create a regular expression pattern for phone number (10 digits)
$phonePattern = "/^[0-9]{10}$/";

// Step 5 & 6: Use preg_match() to validate email and phone number

// Email validation
if (preg_match($emailPattern, $email)) {
    echo "Valid Email Address.<br>";
} else {
    echo "Invalid Email Address.<br>";
}

// Phone number validation
if (preg_match($phonePattern, $phone)) {
    echo "Valid Phone Number.";
} else {
    echo "Invalid Phone Number.";
}
?>
